# Generic ROS Message Package

ROS package message definition reference

## AckermannCurrent.msg

Ackermann chassis current

| Type | Name | Unit | Meaning | Description |
|----------|----------|------|----------|------------|
| float32 | steering | A | steering motor | positive left negative right |
| float32 | left | A | left motor | positive forward negative reverse |
| float32 | right | A | right motor | positive forward negative reverse |

## AckermannSpeed.msg

Ackermann chassis wheel speed + angle

| Type | Name | Unit | Meaning | Description |
|----------|----------|--------|----------|------------|
| float32 | steering | rad | steering angle | positive left negative right |
| int16 | left | mm/s | left wheel speed | positive forward negative reverse |
| int16 | right | mm/s | right wheel speed | positive forward negative reverse |

## AutoCharge.msg

automatic charging module

| Type | Name | Unit | Meaning | Description |
|-------|---------------|---------|----------------|--------------------------------|
| bool | online | boolean | automatic charging module online | false: offline true: online |
| uint8 | state | number | automatic charging state | 0: idle 1: infrared automatic charging 2: laser automatic charging |
| bool | relays | boolean | charging contact relay | false: off true: on |
| bool | limit\_switch | boolean | charging dock limit switch | false: not triggered true: triggered |
| bool | voltage | boolean | charging contact voltage | false: not detected true: detected |
| uint8 | infrared | number | infrared automatic charging state | 0: searching for the center signal <br> 1: center signal found <br> 2: signal lost <br> 3: charging contact detected <br> 4: docking successful <br> 5: docking error ( collision or disconnection during charging )<br> 7: disable automatic charging and withdraw the chassis <br> 8: automatic charging task completed / infrared automatic charging task disabled |

## BatteryState.msg

mainboard battery measurements

| Type | Name | Unit | Meaning | Description |
|---------|---------|------|------------|------------------|
| uint8 | percent | % | state of charge percentage | estimated from voltage |
| float32 | voltage | V | battery voltage | Unit 0.1V |

## Bms.msg

mainboard BMS measurement

| Type | Name | Unit | Meaning | Description |
|-----------|-----------------------------|---------|------------|---------------------------|
| bool | is\_offline | boolean | offline flag | false: online true: offline |
| bool | is\_warning | boolean | alarm flag | false: no alarm true: alarm active |
| bool | charge\_mos\_is\_open | boolean | charging MOS | false: off true: on |
| bool | discharge\_mos\_is\_open | boolean | discharging MOS | false: off true: on |
| uint8 | state | number | charge/discharge state | 0: idle 1: charging 2: discharging |
| float32 | voltage | V | voltage | |
| float32 | current | A | current | |
| float32 | soc | % | state of charge | |
| float32 | remain\_capacity | Ah | remaining capacity | |
| int8 | maximum\_temperature\_value | C | maximum temperature | |
| int8 | minimum\_temperature\_value | C | minimum temperature | |
| uint8\[\] | warning | array | alarm information | |

## ChassisDate.msg

chassis shipment date

| Type | Name | Unit | Meaning | Description |
|-------|-------|--------|------|------------|
| uint8 | year | number | year | omitted 20 prefix |
| uint8 | month | number | month | 1 \-> 12 |
| uint8 | day | number | day | 1 \-> 31 |

## ChassisParameter.msg

chassis parameters

| Type | Name | Unit | Meaning | Description |
|--------|-----------------|--------|------------|------|
| uint16 | track\_width | mm | track width | |
| uint16 | wheel\_base | mm | wheelbase | |
| uint16 | wheel\_diameter | mm | diameter | |
| uint16 | gear\_ratio | number | gear ratio | |
| uint16 | encoder\_line | number | encoder line count | |

## ChassisState.msg

chassis state

| Type | Name | Unit | Meaning | Description |
|-------|-------------------------|---------|--------------|--------------------------------------------|
| uint8 | control\_mode | number | control mode | 0: idle 1: remote control 2: communication control 3: external control |
| bool | auto\_charge\_enable | boolean | automatic charging enabled | false: off true: on |
| bool | motor\_drive\_error | boolean | motor controller alarm | false: not triggered true: triggered |
| bool | motor\_encoder\_error | boolean | encoder fault | false: not triggered true: triggered |
| bool | stop\_button | boolean | emergency stop button | false: released true: pressed |
| bool | remote\_control\_stop | boolean | remote emergency stop | false: released true: enabled |
| bool | software\_stop | boolean | software emergency stop | false: released true: enabled |
| bool | front\_collision | boolean | front bumper triggered | false: not triggered true: triggered |
| bool | back\_collision | boolean | rear bumper triggered | false: not triggered true: triggered |
| bool | remote\_control\_online | boolean | remote control online | false: offline true: online |
| bool | motor\_drive\_online | boolean | motor controller online | false: offline true: online |

## ChassisVelocity.msg

chassis linear and angular velocities

| Type | Name | Unit | Meaning | Description |
|---------|---------|---------|--------------|------|
| float64 | linear | m/s | linear velocity | |
| float64 | angular | rad/s | angular velocity | |

## DaliBms.msg

battery BMS information

| Type | Name | Unit | Meaning | Description |
|-------------|--------------------------------------|---------|---------------------------|------------------------|
| float32 | cumulative\_total\_voltage | V | accumulated total voltage | |
| float32 | gather\_total\_voltage | V | measured total voltage | |
| float32 | current | A | current | positive when charging negative when discharging |
| float32 | soc | % | SOC | |
| float32 | maximum\_cell\_voltage\_value | V | maximum cell voltage value | |
| uint8 | no\_of\_cell\_with\_maximum\_voltage | number | cell with the highest value cell index | |
| float32 | minimum\_cell\_voltage\_value | V | minimum cell voltage value | |
| uint8 | no\_of\_cell\_with\_minimum\_voltage | number | cell with the lowest value cell index | |
| int8 | maximum\_temperature\_value | C | maximum cell temperature value | |
| uint8 | maximum\_temperature\_cell\_no | number | maximum cell temperature cell index | |
| int8 | minimum\_temperature\_value | C | minimum cell temperature value | |
| uint8 | minimum\_temperature\_cell\_no | number | minimum cell temperature cell index | |
| uint8 | state | number | charge/discharge state | 0: idle 1: charging 2: discharging |
| uint8 | charge\_mos\_state | number | charging MOS transistor state | |
| uint8 | discharge\_mos\_status | number | discharging MOS transistor state | |
| uint8 | bms\_life | number | cycle count | |
| float32 | remain\_capacity | Ah | remaining capacity | |
| uint8 | no\_of\_battery\_string | number | number of series-connected cells | |
| uint8 | no\_of\_temperature | number | number of temperature sensors | |
| bool | charger\_status | boolean | charger state | 0: disconnected 1: connected |
| bool | load\_status | boolean | load connection state | 0: disconnected 1: connected |
| bool\[4\] | di\_state | array | DI state | |
| bool\[4\] | do\_state | array | DO state | |
| float32\[\] | cell\_voltage | array | cell voltage | |
| int8\[\] | cell\_temperature | array | cell temperature | |
| bool\[48\] | cell\_balance\_state | array | balancing state | 0: off 1: on |
| bool | cell\_volt\_high\_level\_1 | boolean | level 1 high cell-voltage alarm | |
| bool | cell\_volt\_high\_level\_2 | boolean | level 2 high cell-voltage alarm | |
| bool | cell\_volt\_low\_level\_1 | boolean | level 1 low cell-voltage alarm | |
| bool | cell\_volt\_low\_level\_2 | boolean | level 2 low cell-voltage alarm | |
| bool | sum\_volt\_high\_level\_1 | boolean | level 1 high total-voltage alarm | |
| bool | sum\_volt\_high\_level\_2 | boolean | level 2 high total-voltage alarm | |
| bool | sum\_volt\_low\_level\_1 | boolean | level 1 low total-voltage alarm | |
| bool | sum\_volt\_low\_level\_2 | boolean | level 2 low total-voltage alarm | |
| bool | chg\_temp\_high\_level\_1 | boolean | level 1 high charging temperature alarm | |
| bool | chg\_temp\_high\_level\_2 | boolean | level 2 high charging temperature alarm | |
| bool | chg\_temp\_low\_level\_1 | boolean | level 1 low charging temperature alarm | |
| bool | chg\_temp\_low\_level\_2 | boolean | level 2 low charging temperature alarm | |
| bool | dischg\_temp\_high\_level\_1 | boolean | level 1 high discharging temperature alarm | |
| bool | dischg\_temp\_high\_level\_2 | boolean | level 2 high discharging temperature alarm | |
| bool | dischg\_temp\_low\_level\_1 | boolean | level 1 low discharging temperature alarm | |
| bool | dischg\_temp\_low\_level\_2 | boolean | level 2 low discharging temperature alarm | |
| bool | chg\_overcurrent\_level\_1 | boolean | level 1 charging overcurrent alarm | |
| bool | chg\_overcurrent\_level\_2 | boolean | level 2 charging overcurrent alarm | |
| bool | dischg\_overcurrent\_level\_1 | boolean | level 1 discharging overcurrent alarm | |
| bool | dischg\_overcurrent\_level\_2 | boolean | level 2 discharging overcurrent alarm | |
| bool | soc\_high\_level\_1 | boolean | SOC level 1 high-value alarm | |
| bool | soc\_high\_level\_2 | boolean | SOC level 2 high-value alarm | |
| bool | soc\_low\_level\_1 | boolean | SOC level 1 low-value alarm | |
| bool | soc\_low\_level\_2 | boolean | SOC level 2 low-value alarm | |
| bool | diff\_volt\_level\_1 | boolean | level 1 excessive voltage-difference alarm | |
| bool | diff\_volt\_level\_2 | boolean | level 2 excessive voltage-difference alarm | |
| bool | diff\_temp\_level\_1 | boolean | level 1 excessive temperature-difference alarm | |
| bool | diff\_temp\_level\_2 | boolean | level 2 excessive temperature-difference alarm | |
| bool | chg\_mos\_temp\_high\_alarm | boolean | charging MOS overtemperature warning | |
| bool | dischg\_mos\_temp\_high\_alarm | boolean | discharging MOS overtemperature warning | |
| bool | chg\_mos\_temp\_sensor\_err | boolean | charging MOS temperature sensor fault | |
| bool | dischg\_mos\_temp\_sensor\_err | boolean | discharging MOS temperature sensor fault | |
| bool | chg\_mos\_adhesion\_err | boolean | charging MOS stuck-on fault | |
| bool | dischg\_mos\_adhesion\_err | boolean | discharging MOS stuck-on fault | |
| bool | chg\_mos\_open\_circuit\_err | boolean | charging MOS open-circuit fault | |
| bool | dischg\_mos\_open\_circuit\_err | boolean | discharging MOS open-circuit fault | |
| bool | afe\_collect\_chip\_err | boolean | AFE measurement chip fault | |
| bool | voltage\_collect\_dropped | boolean | cell measurement connection lost | |
| bool | cell\_temp\_sensor\_err | boolean | cell temperature sensor fault | |
| bool | eeprom\_err | boolean | EEPROM storage fault | |
| bool | rtc\_err | boolean | RTC clock fault | |
| bool | precharge\_failure | boolean | precharge failure | |
| bool | communication\_failure | boolean | vehicle communication fault | |
| bool | internal\_communication\_failure | boolean | internal communication module fault | |
| bool | current\_module\_fault | boolean | current measurement module fault | |
| bool | sum\_voltage\_detect\_fault | boolean | internal total-voltage measurement module fault | |
| bool | short\_circuit\_protect\_fault | boolean | short-circuit protection fault | |
| bool | low\_volt\_forbidden\_chg\_fault | boolean | charging prohibited due to low voltage | |
| uint8 | fault\_code | boolean | fault code | |

## FourWheelDiffCurrent.msg

four-wheel differential chassis current

| Type | Name | Unit | Meaning | Description |
|---------|--------------|------|------|------------|
| float32 | front\_left | A | front left | positive forward negative reverse |
| float32 | front\_right | A | front right | positive forward negative reverse |
| float32 | rear\_left | A | rear left | positive forward negative reverse |
| float32 | rear\_right | A | rear right | positive forward negative reverse |

## FourWheelDiffSpeed.msg

four-wheel differential chassis wheel speed

| Type | Name | Unit | Meaning | Description |
|-------|--------------|------|------|------------|
| int16 | front\_left | mm/s | front left | positive forward negative reverse |
| int16 | front\_right | mm/s | front right | positive forward negative reverse |
| int16 | rear\_left | mm/s | rear left | positive forward negative reverse |
| int16 | rear\_right | mm/s | rear right | positive forward negative reverse |

## FourWheelSteerAngle.msg

four-wheel independent steering chassis angle

| Type | Name | Unit | Meaning | Description |
|---------|--------------|------|----------|------------|
| float32 | front\_left | rad | front-left steering | positive left negative right |
| float32 | front\_right | rad | front-right steering | positive left negative right |
| float32 | rear\_left | rad | rear-left steering | positive left negative right |
| float32 | rear\_right | rad | rear-right steering | positive left negative right |

## FourWheelSteerCurrent.msg

four-wheel independent steering chassis current

| Type | Name | Unit | Meaning | Description |
|---------|------------------------|------|----------|------------|
| float32 | front\_steering\_left | A | front-left steering | positive left negative right |
| float32 | front\_steering\_right | A | front-right steering | positive left negative right |
| float32 | rear\_steering\_left | A | rear-left steering | positive left negative right |
| float32 | rear\_steering\_right | A | rear-right steering | positive left negative right |
| float32 | front\_left | A | front-left drive | positive forward negative reverse |
| float32 | front\_right | A | front-right drive | positive forward negative reverse |
| float32 | rear\_left | A | rear-left drive | positive forward negative reverse |
| float32 | rear\_right | A | rear-right drive | positive forward negative reverse |

## FourWheelSteerEncoder.msg

four-wheel independent steering chassis encoder count

| Type | Name | Unit | Meaning | Description |
|--------|--------------|--------|----------|------|
| uint32 | front\_left | number | front-left count | |
| uint32 | front\_right | number | front-right count | |
| uint32 | rear\_left | number | rear-left count | |
| uint32 | rear\_right | number | rear-right count | |

## FourWheelSteerMotion.msg

four-wheel independent steering chassis motion state

| Type | Name | Unit | Meaning | Description |
|---------|--------------|--------|------------|------------------------------------|
| uint8 | motion\_mode | number | motion mode | 0: Ackermann / rotation in place 1: four-wheel independent steering mode |
| float32 | linear | m/s | linear velocity | used in Ackermann mode forward positive; reverse negative |
| float32 | steering | rad | angle | used in Ackermann mode left positive; right negative |
| float32 | angular | rad/s | angular velocity | used in Ackermann mode rotation in place takes priority counterclockwise positive |
| float32 | linear\_x | m/s | longitudinal velocity | used in four-wheel independent steering mode forward positive; reverse negative |
| float32 | linear\_y | m/s | lateral velocity | used in four-wheel independent steering mode left positive; right negative |
| float32 | angular\_z | rad/s | angular velocity | used in four-wheel independent steering mode counterclockwise positive |

## FourWheelSteerSpeed.msg

four-wheel independent steering chassis speed

| Type | Name | Unit | Meaning | Description |
|-------|--------------|------|----------|------------|
| int16 | front\_left | mm/s | front-left drive | positive forward negative reverse |
| int16 | front\_right | mm/s | front-right drive | positive forward negative reverse |
| int16 | rear\_left | mm/s | rear-left drive | positive forward negative reverse |
| int16 | rear\_right | mm/s | rear-right drive | positive forward negative reverse |

## HardwareVersion.msg

hardware version

| Type | Name | Unit | Meaning | Description |
|------------|---------|-------|----------|------|
| uint8\[8\] | version | array | hardware version | reserved |

## LedStrip.msg

LED strip parameters

| Type | Name | Unit | Meaning | Description |
|---------|------------|--------|----------|---------------------------------|
| uint8 | id | number | LED strip ID | range 1\-4 |
| uint8 | mode | number | lighting mode | 0: steady 1: flashing 2: breathing |
| uint8 | brightness | % | brightness | range 0\-100 |
| float32 | interval | s | interval | range 0\.0 \- 25\.5 one decimal place |
| uint8 | r | number | red | |
| uint8 | g | number | green | |
| uint8 | b | number | blue | |


## LedStrips.msg

multiple channels LED strip parameters

| Type | Name | Unit | Meaning | Description |
|------------|------|--------|----------|------|
| struct\[\] | leds | struct | multiple LED strips | reserved |

## RemoteControl.msg

remote control data

| Type | Name | Unit | Meaning | Description |
|-------|-------------------|---------|--------------|--------------------------|
| bool | online | boolean | remote control connection state | false: offline true: online |
| int16 | rocker\_left\_x | number | left joystick, horizontal | left:\-584 center:0 right:583 |
| int16 | rocker\_left\_y | number | left joystick, vertical | down:\-584 center:0 up:583 |
| int16 | rocker\_right\_x | number | right joystick, horizontal | left:\-584 center:0 right:583 |
| int16 | rocker\_right\_y | number | right joystick, vertical | down:\-584 center:0 up:583 |
| int16 | round\_left\_vra | number | left dial, fore/aft | reverse:\-584 center:0 forward:583 |
| int16 | round\_right\_vrb | number | right dial, fore/aft | reverse:\-584 center:0 forward:583 |
| uint8 | key\_swa | number | switch swa | 0: down 1: center 2: up 3: reserved |
| uint8 | key\_swb | number | switch swb | 0: down 1: center 2: up 4: reserved |
| uint8 | key\_swc | number | switch swc | 0: down 1: center 2: up 5: reserved |
| uint8 | key\_swd | number | switch swd | 0: down 1: center 2: up 6: reserved |

## SoftwareVersion.msg

software version

| Type | Name | Unit | Meaning | Description |
|------------|----------|--------|--------------|----------------------|
| uint8 | major | number | major version | |
| uint8 | minor | number | minor version | |
| uint8 | revision | number | revision | |
| uint8 | reserved | number | reserved | |
| uint8 | year | number | year | |
| uint8 | month | number | month | |
| uint8 | day | number | day | |
| uint8 | other | number | other | |
| uint8\[8\] | version | array | software version information | raw software version byte array |

## TwoWheelDiffCurrent.msg

two-wheel differential chassis current

| Type | Name | Unit | Meaning | Description |
|---------|-------|------|------|------------|
| float32 | left | A | left | positive forward negative reverse |
| float32 | right | A | right | positive forward negative reverse |

## TwoWheelDiffSpeed.msg

two-wheel differential chassis wheel speed

| Type | Name | Unit | Meaning | Description |
|-------|-------|------|------|------------|
| int16 | left | mm/s | left | positive forward negative reverse |
| int16 | right | mm/s | right | positive forward negative reverse |

## Version history

Current: V 1.0.2 <br>

V 1.0.2 <br>
++ added mainboard measurement BMS message definitions

V 1.0.1 <br>
++ added BMS message definitions

V 1.0.0 <br>
++ initial release
