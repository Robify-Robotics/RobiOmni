# robiomni Chassis ROS Package

ROS package topic and parameter reference

## ROS package information

Package name: robiomni <br>
Executable: robiomni_node <br>
Node name: robiomni_node

## Topics

Published topic: /robiomni/frame_info <br>
Message type: robiomni::msg::Frame <br>
Description: raw data

Published topic: /robiomni/drive_steer_front_left_error_info <br>
Message type: std_msgs::msg::UInt16 <br>
Description: front-left steering motor controller fault [0: no fault] [other: fault present]

Published topic: /robiomni/drive_steer_front_right_error_info <br>
Message type: std_msgs::msg::UInt16 <br>
Description: front-right steering motor controller fault [0: no fault] [other: fault present]

Published topic: /robiomni/drive_steer_rear_left_error_info <br>
Message type: std_msgs::msg::UInt16 <br>
Description: rear-left steering motor controller fault [0: no fault] [other: fault present]

Published topic: /robiomni/drive_steer_rear_right_error_info <br>
Message type: std_msgs::msg::UInt16 <br>
Description: rear-right steering motor controller fault [0: no fault] [other: fault present]

Published topic: /robiomni/drive_front_left_error_info <br>
Message type: robiomni::msg::DriveSdfzError <br>
Description: front-left drive motor controller fault

Published topic: /robiomni/drive_front_right_error_info <br>
Message type: robiomni::msg::DriveSdfzError <br>
Description: front-right drive motor controller fault

Published topic: /robiomni/drive_rear_left_error_info <br>
Message type: robiomni::msg::DriveSdfzError <br>
Description: rear-left drive motor controller fault

Published topic: /robiomni/drive_rear_right_error_info <br>
Message type: robiomni::msg::DriveSdfzError <br>
Description: rear-right drive motor controller fault

Published topic: /robiomni/auto_charge_info <br>
Message type: robot_ros2_msgs::msg::AutoCharge <br>
Description: automatic charging status

Published topic: /robiomni/battery_info <br>
Message type: robot_ros2_msgs::msg::BatteryState <br>
Description: battery measurements from the mainboard

Published topic: /robiomni/bms_info <br>
Message type: robot_ros2_msgs::msg::Bms <br>
Description: battery bms information

Published topic: /robiomni/state_info <br>
Message type: robot_ros2_msgs::msg::ChassisState <br>
Description: chassis state

Published topic: /robiomni/remote_control_info <br>
Message type: robot_ros2_msgs::msg::RemoteControl <br>
Description: remote control data

Published topic: /robiomni/angle_info <br>
Message type: robot_ros2_msgs::msg::FourWheelSteerAngle <br>
Description: chassis steering motor angles

Published topic: /robiomni/current_info <br>
Message type: robot_ros2_msgs::msg::FourWheelSteerCurrent <br>
Description: chassis motor currents

Published topic: /robiomni/encoder_count_info <br>
Message type: robot_ros2_msgs::msg::FourWheelSteerEncoder <br>
Description: drive motor encoder counts

Published topic: /robiomni/motion_info <br>
Message type: robot_ros2_msgs::msg::FourWheelSteerMotion <br>
Description: chassis motion state

Published topic: /robiomni/speed_info <br>
Message type: robot_ros2_msgs::msg::FourWheelSteerSpeed <br>
Description: drive motor speeds

Published topic: /robiomni/odom_info <br>
Message type: nav_msgs::msg::Odometry <br>
Description: chassis odometry ( odometry is calculated in FTFD mode and Ackermann rotation in place only )

Published topic: /robiomni/battery_state <br>
Message type: sensor_msgs::msg::BatteryState <br>
Description: battery information

Published topic: /robiomni/std_stop_button_info <br>
Message type: std_msgs::msg::Bool <br>
Description: unified emergency stop button state

Published topic: /robiomni/std_software_stop_info <br>
Message type: std_msgs::msg::Bool <br>
Description: unified software emergency stop state

Published topic: /robiomni/std_front_collision_info <br>
Message type: std_msgs::msg::Bool <br>
Description: unified front collision status

Published topic: /robiomni/std_rear_collision_info <br>
Message type: std_msgs::msg::Bool <br>
Description: unified rear collision status

---

Subscribed topic: /robiomni/velocity_ctrl <br>
Message type: geometry_msgs::msg::Twist <br>
Description: linear velocity, angular velocity, and steering angle control

Subscribed topic: /robiomni/ftfd_ctrl <br>
Message type: geometry_msgs::msg::Twist <br>
Description: linear and angular velocity control

Subscribed topic: /robiomni/ackermann_ctrl <br>
Message type: geometry_msgs::msg::Twist <br>
Description: speed and steering angle control

Subscribed topic: /robiomni/double_ackermann_ctrl <br>
Message type: geometry_msgs::msg::Twist <br>
Description: Double Ackermann mode (0x02). linear.x is forward velocity in m/s; angular.z is the steering angle in radians, not angular velocity. linear.y is unused. Use angular.z=0 for straight travel and a nonzero steering angle to turn while moving. This topic does not command rotation in place.

Subscribed topic: /robiomni/rotate_ctrl <br>
Message type: geometry_msgs::msg::Twist <br>
Description: rotation-in-place control

Subscribed topic: /robiomni/motion_ctrl <br>
Message type: robot_ros2_msgs::msg::FourWheelSteerMotion <br>
Description: chassis motion control

Subscribed topic: /robiomni/auto_charge_ctrl <br>
Message type: std_msgs::UInt8 <br>
Description: automatic charging control, [0: disable automatic charging] [1: enable infrared automatic charging] [2: enable laser automatic charging]

Subscribed topic: /robiomni/collision_clean <br>
Message type: std_msgs::msg::Empty <br>
Description: clear collision status

Subscribed topic: /robiomni/lamp_ctrl <br>
Message type: std_msgs::msg::Bool <br>
Description: lighting control, [true: on] [false: off]

Subscribed topic: /robiomni/odom_clean <br>
Message type: std_msgs::msg::Empty <br>
Description: reset odometry

Subscribed topic: /robiomni/std_stop_ctrl <br>
Message type: std_msgs::msg::Bool <br>
Description: reserved topic; not implemented, unified software emergency stop, [true: active] [false: inactive]

Subscribed topic: /robiomni/std_all_collision_clean <br>
Message type: std_msgs::msg::Empty <br>
Description: unified all-collision status clearing

Subscribed topic: /robiomni/std_front_collision_clean <br>
Message type: std_msgs::msg::Empty <br>
Description: unified front collision status clearing

Subscribed topic: /robiomni/std_rear_collision_clean <br>
Message type: std_msgs::msg::Empty <br>
Description: reserved topic; not implemented, unified rear collision status clearing

Subscribed topic: /robiomni/std_all_lamp_ctrl <br>
Message type: std_msgs::msg::Bool <br>
Description: unified all-lighting control, [true: on] [false: off]

Subscribed topic: /robiomni/std_front_lamp_ctrl <br>
Message type: std_msgs::msg::Bool <br>
Description: unified front lighting control, [true: on] [false: off]

Subscribed topic: /robiomni/std_rear_lamp_ctrl <br>
Message type: std_msgs::msg::Bool <br>
Description: reserved topic; not implemented, unified rear lighting control, [true: on] [false: off]

## Parameters

Parameter name: robiomni_odom_enable <br>
Data type: bool <br>
Default value: true <br>
Parameter description: enable odometry

Parameter name: robiomni_log_display <br>
Data type: bool <br>
Default value: true <br>
Parameter description: enable log output

Parameter name: robiomni_original_display <br>
Data type: bool <br>
Default value: false <br>
Parameter description: enable raw data output

Parameter name: robiomni_skip_find <br>
Data type: bool <br>
Default value: true <br>
Parameter description: When adapter discovery reports zero devices, continue by attempting to open device index 0. If false, report discovery failure instead of continuing. This option does not bypass discovery itself.

## Version history

Current: V 1.0.7 <br>

V 1.0.7 <br>
++ Compatible protocol version "robiomni Chassis CAN Communication Protocol v1.0_2025.3.4" and "robiomni Mini Chassis CAN Communication Protocol v2.2_2025.12.2" <br>
++ Compatible message package version [robot_ros2_msgs v1.0.2] <br>
++ fixed can transmission bug

V 1.0.6 <br>
++ Compatible protocol version "robiomni Chassis CAN Communication Protocol v1.0_2025.3.4" and "robiomni Mini Chassis CAN Communication Protocol v2.2_2025.12.2" <br>
++ Compatible message package version [robot_ros2_msgs v1.0.2] <br>
++ fixed can receive error clearing

V 1.0.5 <br>
++ Compatible protocol version "robiomni Chassis CAN Communication Protocol v1.0_2025.3.4" and "robiomni Mini Chassis CAN Communication Protocol v2.2_2025.12.2" <br>
++ Compatible message package version [robot_ros2_msgs v1.0.2] <br>
++ fixed can reception bug

V 1.0.4 <br>
++ Compatible protocol version "robiomni Chassis CAN Communication Protocol v1.0_2025.3.4" and "robiomni Mini Chassis CAN Communication Protocol v2.2_2025.12.2" <br>
++ Compatible message package version [robot_ros2_msgs v1.0.2] <br>
++ fixed standard topic publishing bug

V 1.0.3 <br>
++ Compatible protocol version "robiomni Chassis CAN Communication Protocol v1.0_2025.3.4" and "robiomni Mini Chassis CAN Communication Protocol v2.2_2025.12.2" <br>
++ Compatible message package version [robot_ros2_msgs v1.0.2] <br>
++ disabled CAN close function <br>
++ added CAN accumulated transmit/receive error filtering <br>
++ updated to match protocol changes <br>
++ added standard message publishers and subscribers <br>
++ Added twist.linear.y to odometry

V 1.0.2 <br>
++ Added a launch option to skip CAN adapter discovery; enabled by default. <br>
++ Changed logging to the official ROS logging API.

V 1.0.1 <br>
++ added double Ackermann control and feedback <br>
++ steering motor fault type changed from bool to uint16

V 1.0.0 <br>
++ initial release

## Other information
