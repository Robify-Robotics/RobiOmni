from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='robiomni',
            executable='robiomni_node',
            name='robiomni_node',
            output='screen',
            parameters=[{
                'robiomni_odom_enable': True,
                'robiomni_log_display': True,
                'robiomni_original_display': False,
                'robiomni_skip_find': True,
            }],
            remappings=[
                # pub: old, new
                ('/robiomni/frame_info',          '/robiomni/frame_info'),
                ('/robiomni/auto_charge_info',    '/robiomni/auto_charge_info'),
                ('/robiomni/battery_info',        '/robiomni/battery_info'),
                ('/robiomni/state_info',          '/robiomni/state_info'),
                ('/robiomni/remote_control_info', '/robiomni/remote_control_info'),
                ('/robiomni/encoder_count_info',  '/robiomni/encoder_count_info'),
                ('/robiomni/motion_info',         '/robiomni/motion_info'),
                ('/robiomni/speed_info',          '/robiomni/speed_info'),
                ('/robiomni/angle_info',          '/robiomni/angle_info'),

                # sub: old, new
                ('/robiomni/velocity_ctrl',    '/robiomni/velocity_ctrl'),
                ('/robiomni/motion_ctrl',      '/robiomni/motion_ctrl'),
                ('/robiomni/lamp_ctrl',        '/robiomni/lamp_ctrl'),
                ('/robiomni/auto_charge_ctrl', '/robiomni/auto_charge_ctrl'),
            ]
        )
    ])