# robiomni ROS2 workspace

Main package: robiomni
Workspace directory: robi_ros2
ROS distribution: humble

Extract this archive on a Linux system with the matching ROS distribution.
Install build dependencies from the source workspace:
source /opt/ros/humble/setup.bash
rosdep install --from-paths src --ignore-src -r -y --rosdistro humble
bash build.sh

After connecting the compatible USB-CAN adapter and configuring its permissions:
bash start.sh

Equivalent launch command:
ros2 launch robiomni robiomni.launch.py

robot_ros2_msgs is included as a required dependency.
Custom main-package message namespaces use robiomni. Topic prefixes now use robiomni. The CAN protocol is unchanged. ARM/x86 32/64-bit CAN libraries are included and selected during
configuration. Build on each destination architecture; do not copy build, devel
or install caches from another computer. CAN library availability does not
guarantee ROS support for all 32-bit systems.

Verified build: x86-64 Ubuntu 22.04 + Humble.
No chassis motion commands were sent during this rename.
