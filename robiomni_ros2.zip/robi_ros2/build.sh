#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")"
source /opt/ros/humble/setup.bash
colcon build --base-paths src --parallel-workers 2
