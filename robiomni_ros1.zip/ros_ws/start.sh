#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")"
source /opt/ros/noetic/setup.bash
source devel/setup.bash
roslaunch robiomni robiomni.launch
