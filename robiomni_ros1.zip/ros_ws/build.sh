#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")"
source /opt/ros/noetic/setup.bash
catkin_make -j2
