# RobiOmni ROS1

Extract into your home directory to create ~/ros_ws. Ubuntu 20.04 with ROS Noetic is required. Run bash build.sh, then bash start.sh. The package name is robiomni and the launch file is robiomni.launch. Source devel/setup.bash in other terminals. USB-CAN hardware and access permissions are required for chassis communication. ARM and x86 vendor libraries are included; rebuild on the target architecture.
