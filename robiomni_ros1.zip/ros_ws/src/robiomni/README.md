# robiomni Chassis ROS Package

ROS package topic and parameter reference

## ROS package information

Package name: robiomni <br>
Executable: robiomni <br>
Node name: robiomni_node

## Topics

Published topic: /robiomni_Motion <br>
Message type: robiomni::ht_motion <br>
Description: motion information

Published topic: /robiomni_System <br>
Message type: robiomni::ht_system <br>
Description: system state 1

Published topic: /robiomni_Drive_Motor <br>
Message type: robiomni::ht_drive_motor <br>
Description: drive motor state

Published topic: /robiomni_Steering_Motor <br>
Message type: robiomni::ht_steering_motor <br>
Description: steering motor state

Published topic: /robiomni_RemoteCtrl_Rocker <br>
Message type: robiomni::ht_rc_rocker <br>
Description: remote control joystick

Published topic: /robiomni_RemoteCtrl_Key <br>
Message type: robiomni::ht_rc_key <br>
Description: remote control dial, switch

Published topic: /robiomni_Charge_State <br>
Message type: robiomni::ht_charge <br>
Description: automatic charging

Published topic: /robiomni_Drive_Motor_Current <br>
Message type: robiomni::ht_drive_motor_current <br>
Description: drive motor currents

Published topic: /robiomni_Drive_Motor_Error <br>
Message type: robiomni::ht_drive_motor_error <br>
Description: drive motor faults

Published topic: /robiomni_Steering_Motor_Current <br>
Message type: robiomni::ht_steering_motor_current <br>
Description: steering motor currents

Published topic: /robiomni_Steering_Motor_Error <br>
Message type: robiomni::ht_steering_motor_error <br>
Description: steering motor faults

Published topic: /robiomni_System_2 <br>
Message type: robiomni::ht_system_2 <br>
Description: system state 2

Published topic: /robiomni_Odom_Info <br>
Message type: nav_msgs::Odometry <br>
Description: odometry, used in four-wheel independent steering mode, in Ackermann mode only rotation in place is accumulated

Published topic: /robiomni_Battery_State <br>
Message type: sensor_msgs::BatteryState <br>
Description: battery information

Published topic: /robiomni_BMS_Info <br>
Message type: robiomni::ht_bms <br>
Description: bms information

Published topic: /robiomni/std_stop_button_info <br>
Message type: std_msgs::Bool <br>
Description: unified emergency stop button state

Published topic: /robiomni/std_software_stop_info <br>
Message type: std_msgs::Bool <br>
Description: unified software emergency stop state

Published topic: /robiomni/std_front_collision_info <br>
Message type: std_msgs::Bool <br>
Description: unified front collision status

Published topic: /robiomni/std_rear_collision_info <br>
Message type: std_msgs::Bool <br>
Description: unified rear collision status

---

Subscribed topic: /robiomni_Control <br>
Message type: geometry_msgs::Twist <br>
Description: Linear and angular velocity control: when linear.x and linear.y are zero and angular.z is nonzero, rotate in place; otherwise use FTFD mode.

Subscribed topic: /robiomni_FTFD_Ctrl <br>
Message type: geometry_msgs::Twist <br>
Description: FTFD mode linear and angular velocity control

Subscribed topic: /robiomni_Ackermann_Ctrl <br>
Message type: geometry_msgs::Twist <br>
Description: Ackermann mode, linear velocity and steering angle control. linear.x is linear velocity; angular.z is the steering angle in radians; linear.y is unused.

Subscribed topic: /robiomni_Double_Ackermann_Ctrl <br>
Message type: geometry_msgs::Twist <br>
Description: double Ackermann mode, linear velocity and steering angle control. linear.x is linear velocity; angular.z is the steering angle in radians; linear.y is unused.

Subscribed topic: /robiomni_Rotate_Ctrl <br>
Message type: geometry_msgs::Twist <br>
Description: rotation-in-place mode, angular.z is angular velocity; linear.x and linear.y are unused.

Subscribed topic: /robiomni_Motion_Ctrl <br>
Message type: robiomni::ht_motion <br>
Description: control using the selected motion mode and its parameters.

Subscribed topic: /robiomni_Charge_Ctrl <br>
Message type: std_msgs::UInt8 <br>
Description: automatic charging control, [0: disable automatic charging] [1: enable infrared automatic charging] [2: enable laser automatic charging]

Subscribed topic: /robiomni_Collision_Clean <br>
Message type: std_msgs::Empty <br>
Description: clear collision status.

Subscribed topic: /robiomni_Lamp_All_Ctrl <br>
Message type: std_msgs::Bool <br>
Description: control all lighting channels.

Subscribed topic: /robiomni_Lamp1_Ctrl <br>
Message type: std_msgs::Bool <br>
Description: lighting channel 1 control.

Subscribed topic: /robiomni_Lamp2_Ctrl <br>
Message type: std_msgs::Bool <br>
Description: lighting channel 2 control.

Subscribed topic: /robiomni_Odom_Clean <br>
Message type: std_msgs::Empty <br>
Description: reset odometry

Subscribed topic: /robiomni/std_stop_ctrl <br>
Message type: std_msgs::Bool <br>
Description: reserved topic; not implemented, unified software emergency stop, [true: active] [false: inactive]

Subscribed topic: /robiomni/std_all_collision_clean <br>
Message type: std_msgs::Empty <br>
Description: unified all-collision status clearing

Subscribed topic: /robiomni/std_front_collision_clean <br>
Message type: std_msgs::Empty <br>
Description: unified front collision status clearing

Subscribed topic: /robiomni/std_rear_collision_clean <br>
Message type: std_msgs::Empty <br>
Description: reserved topic; not implemented, unified rear collision status clearing

Subscribed topic: /robiomni/std_all_lamp_ctrl <br>
Message type: std_msgs::Bool <br>
Description: unified all-lighting control, [true: on] [false: off]

Subscribed topic: /robiomni/std_front_lamp_ctrl <br>
Message type: std_msgs::Bool <br>
Description: unified front lighting control, [true: on] [false: off]

Subscribed topic: /robiomni/std_rear_lamp_ctrl <br>
Message type: std_msgs::Bool <br>
Description: unified rear lighting control, [true: on] [false: off]

## Parameters

Parameter name: robiomni_odom_enable <br>
Data type: bool <br>
Default value: true <br>
Parameter description: enable odometry

## Version history

Current: V 1.1.7 <br>

V 1.1.7 <br>
++ exit the node when disconnected, launch respawn interval 1s <br>

V 1.1.6 <br>
++ Compatible protocol "robiomni Mini Chassis CAN Communication Protocol v2.2_2025.12.2" and "robiomni Chassis CAN Communication Protocol v1.0_2025.3.4" <br>
++ fixed can receive limit issue

V 1.1.5 <br>
++ Compatible protocol "robiomni Mini Chassis CAN Communication Protocol v2.2_2025.12.2" and "robiomni Chassis CAN Communication Protocol v1.0_2025.3.4" <br>
++ fixed can reception bug

V 1.1.4 <br>
++ Compatible protocol "robiomni Mini Chassis CAN Communication Protocol v2.2_2025.12.2" and "robiomni Chassis CAN Communication Protocol v1.0_2025.3.4" <br>
++ added initial values for standard battery messages

V 1.1.3 <br>
++ initial upload
++ added unified topic publishers and subscribers <br>
++ updated for the protocol "robiomni Mini Chassis CAN Communication Protocol v2.2_2025.12.2" and "robiomni Chassis CAN Communication Protocol v1.0_2025.3.4" <br>
++ Fixed the CAN message frame data type for BMS data <br>
++ Added twist.linear.y to odometry

## Other information


## Automatic CAN library selection

The build selects libcontrolcan.so using CMAKE_SYSTEM_PROCESSOR and the target
compiler pointer size (CMAKE_SIZEOF_VOID_P):

| Target family | 32-bit | 64-bit |
| --- | --- | --- |
| ARM | lib/arm/32bit/libcontrolcan.so | lib/arm/64bit/libcontrolcan.so |
| x86 | lib/x86/32bit/libcontrolcan.so | lib/x86/64bit/libcontrolcan.so |

Run catkin_make on the destination Linux/ROS system; no manual library copying
is required. Unsupported architectures and missing libraries fail configuration
with an explicit error. When moving to another architecture, use the source
workspace and rebuild without the previous machine's build/devel caches.
The availability of a CAN library does not guarantee ROS/OS support for every
32-bit platform. ARM64 is the build-verified platform for this update.
