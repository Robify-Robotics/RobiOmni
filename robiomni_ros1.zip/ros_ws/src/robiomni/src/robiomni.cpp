#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include "controlcan.h"

#include <ctime>
#include <cstdlib>
#include "unistd.h"

#include <iostream>

#include "ros/ros.h"
#include <sstream>
#include <geometry_msgs/Twist.h>
#include <std_msgs/Bool.h>
#include <std_msgs/String.h>
#include <std_msgs/Empty.h>
#include <std_msgs/UInt8.h>
#include <std_msgs/Int8.h>

#include <string>
#include <sensor_msgs/JointState.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/BatteryState.h>

#include <ctime>
#include <stdint.h>

#include "robiomni/ht_drive_motor.h"    //自定义消息类型
#include "robiomni/ht_motion.h"         //自定义消息类型
#include "robiomni/ht_steering_motor.h" //自定义消息类型
#include "robiomni/ht_system.h"         //自定义消息类型
#include "robiomni/ht_control.h"        //自定义消息类型

#include "robiomni/ht_rc_key.h"
#include "robiomni/ht_rc_rocker.h"
#include "robiomni/ht_charge.h"
#include "robiomni/ht_drive_motor_current.h"
#include "robiomni/ht_drive_motor_error.h"
#include "robiomni/ht_steering_motor_current.h"
#include "robiomni/ht_steering_motor_error.h"
#include "robiomni/ht_system_2.h"
#include "robiomni/ht_bms.h"

#include "robiomni.h"

#define PI 3.141592653

#define angle_to_rad(angle) ((float)(((angle) * 3.14159265f) / 180.0f))
#define rad_to_angle(rad) ((float)(((rad) * 180.0f) / 3.14159265f))

VCI_BOARD_INFO pInfo; // 用来获取设备信息。
using namespace std;

struct Odom
{
  double x = 0;
  double y = 0;
  double yaw = 0;
  ros::Time last_time;
  nav_msgs::Odometry value;

  void clean(void)
  {
    x = 0; y = 0; yaw = 0;
    value.pose.pose.position.x = x;
    value.pose.pose.position.y = y;
    last_time = ros::Time::now();
  }
};

s8 mode = 2;
s16 angular_velocity = 0.0;
s16 angle = 0.0;
s16 linear_velocity = 0.0;

Odom odom;
bool odom_enable = true;

boost::array<double, 36> cov_array = {1e-3, 0, 0, 0, 0, 0,
  0, 1e-3, 0, 0, 0, 0,
  0, 0, 1e6, 0, 0, 0,
  0, 0, 0, 1e6, 0, 0,
  0, 0, 0, 0, 1e6, 0,
  0, 0, 0, 0, 0, 1e3};

void odomCalculation(Odom &odo, ros::Publisher &pub, double x, double y, double z)
{
  if(odom_enable == false) {return;}

  odo.value.header.stamp = ros::Time::now();
  odo.value.header.frame_id = "odom";
  odo.value.child_frame_id = "base_link";

  double vx = x;
  double vy = y;
  double vyaw = z;
  double dt = (ros::Time::now() - odo.last_time).toSec();
  odo.last_time = ros::Time::now();

  double dx = (vx * cos(odo.yaw) - vy * sin(odo.yaw)) * dt;
  double dy = (vx * sin(odo.yaw) + vy * cos(odo.yaw)) * dt;
  double dyaw = vyaw * dt;

  odo.x += dx;
  odo.y += dy;
  odo.yaw += dyaw;

  geometry_msgs::Quaternion q = tf::createQuaternionMsgFromYaw(odo.yaw);

  odo.value.pose.pose.position.x = odo.x;
  odo.value.pose.pose.position.y = odo.y;
  odo.value.pose.pose.position.z = 0;
  odo.value.pose.pose.orientation = q;
  odo.value.twist.twist.linear.x = vx;
  odo.value.twist.twist.linear.y = vy;
  odo.value.twist.twist.angular.z = vyaw;
  odo.value.pose.covariance = cov_array;
  odo.value.twist.covariance = cov_array;

  pub.publish(odo.value);
}

void sendSpeedAkmMode(double linear, double steering, double angular)
{
  VCI_CAN_OBJ tx_buff;

  tx_buff.ID = 0x001;
  tx_buff.RemoteFlag = 0;
  tx_buff.ExternFlag = 0;
  tx_buff.SendType = 0;
  tx_buff.DataLen = 8;

  tx_buff.Data[0] = 0x01;
  tx_buff.Data[1] = 0x00;
  tx_buff.Data[2] = (((int16_t)(linear * 1000)) >> 0) & 0x00FF;
  tx_buff.Data[3] = (((int16_t)(linear * 1000)) >> 8) & 0x00FF;
  tx_buff.Data[4] = (((int16_t)(rad_to_angle(steering) * 100.0)) >> 0) & 0x00FF;
  tx_buff.Data[5] = (((int16_t)(rad_to_angle(steering) * 100.0)) >> 8) & 0x00FF;
  tx_buff.Data[6] = (((int16_t)(angular * 1000)) >> 0) & 0x00FF;
  tx_buff.Data[7] = (((int16_t)(angular * 1000)) >> 8) & 0x00FF;

#if 0
  for(int loop = 0; loop < 8; loop++)
  {
    printf("%02X ", tx_buff.Data[loop]);
  }
  printf("\n");
#endif

  if (VCI_Transmit(VCI_USBCAN2, 0, 0, &tx_buff, 1) == 1)
  {
    // printf("TX data successful!\n");
  }
}

void sendSpeedFTFDMode(double vx, double vy, double vz)
{
  VCI_CAN_OBJ tx_buff;

  tx_buff.ID = 0x001;
  tx_buff.RemoteFlag = 0;
  tx_buff.ExternFlag = 0;
  tx_buff.SendType = 0;
  tx_buff.DataLen = 8;

  tx_buff.Data[0] = 0x01;
  tx_buff.Data[1] = 0x01;
  tx_buff.Data[2] = (((int16_t)(vx * 1000)) >> 0) & 0x00FF;
  tx_buff.Data[3] = (((int16_t)(vx * 1000)) >> 8) & 0x00FF;
  tx_buff.Data[4] = (((int16_t)(vy * 1000)) >> 0) & 0x00FF;
  tx_buff.Data[5] = (((int16_t)(vy * 1000)) >> 8) & 0x00FF;
  tx_buff.Data[6] = (((int16_t)(vz * 1000)) >> 0) & 0x00FF;
  tx_buff.Data[7] = (((int16_t)(vz * 1000)) >> 8) & 0x00FF;

#if 0
  for(int loop = 0; loop < 8; loop++)
  {
    printf("%02X ", tx_buff.Data[loop]);
  }
  printf("\n");
#endif

  if (VCI_Transmit(VCI_USBCAN2, 0, 0, &tx_buff, 1) == 1)
  {
    // printf("TX data successful!\n");
  }
}

void sendSpeedDoubleAkmMode(double linear, double steering, double angular)
{
  VCI_CAN_OBJ tx_buff;

  tx_buff.ID = 0x001;
  tx_buff.RemoteFlag = 0;
  tx_buff.ExternFlag = 0;
  tx_buff.SendType = 0;
  tx_buff.DataLen = 8;

  tx_buff.Data[0] = 0x01;
  tx_buff.Data[1] = 0x02;
  tx_buff.Data[2] = (((int16_t)(linear * 1000)) >> 0) & 0x00FF;
  tx_buff.Data[3] = (((int16_t)(linear * 1000)) >> 8) & 0x00FF;
  tx_buff.Data[4] = (((int16_t)(rad_to_angle(steering) * 100.0)) >> 0) & 0x00FF;
  tx_buff.Data[5] = (((int16_t)(rad_to_angle(steering) * 100.0)) >> 8) & 0x00FF;
  tx_buff.Data[6] = (((int16_t)(angular * 1000)) >> 0) & 0x00FF;
  tx_buff.Data[7] = (((int16_t)(angular * 1000)) >> 8) & 0x00FF;

#if 0
  for(int loop = 0; loop < 8; loop++)
  {
    printf("%02X ", tx_buff.Data[loop]);
  }
  printf("\n");
#endif

  if (VCI_Transmit(VCI_USBCAN2, 0, 0, &tx_buff, 1) == 1)
  {
    // printf("TX data successful!\n");
  }
}

void sendChargeCtrl(uint8_t charge_type)
{
  VCI_CAN_OBJ tx_buff;

  if ((charge_type != 0x00) && (charge_type != 0x01) && (charge_type != 0x02))
  {
    return;
  }

  tx_buff.ID = 0x001;
  tx_buff.RemoteFlag = 0;
  tx_buff.ExternFlag = 0;
  tx_buff.SendType = 0;
  tx_buff.DataLen = 8;

  tx_buff.Data[0] = 0x02;
  tx_buff.Data[1] = charge_type;
  tx_buff.Data[2] = 0x00;
  tx_buff.Data[3] = 0x00;
  tx_buff.Data[4] = 0x00;
  tx_buff.Data[5] = 0x00;
  tx_buff.Data[6] = 0x00;
  tx_buff.Data[7] = 0x00;

  if (VCI_Transmit(VCI_USBCAN2, 0, 0, &tx_buff, 1) == 1)
  {
    // printf("TX data successful!\n");
  }
}

void sendCollisionClean(void)
{
  VCI_CAN_OBJ tx_buff;

  tx_buff.ID = 0x001;
  tx_buff.RemoteFlag = 0;
  tx_buff.ExternFlag = 0;
  tx_buff.SendType = 0;
  tx_buff.DataLen = 8;

  tx_buff.Data[0] = 0x20;
  tx_buff.Data[1] = 0x01;
  tx_buff.Data[2] = 0x00;
  tx_buff.Data[3] = 0x00;
  tx_buff.Data[4] = 0x00;
  tx_buff.Data[5] = 0x00;
  tx_buff.Data[6] = 0x00;
  tx_buff.Data[7] = 0x00;

  if (VCI_Transmit(VCI_USBCAN2, 0, 0, &tx_buff, 1) == 1)
  {
    // printf("TX data successful!\n");
  }
}

void sendLampCtrl(uint8_t ch, bool enable)
{
  VCI_CAN_OBJ tx_buff;

  tx_buff.ID = 0x001;
  tx_buff.RemoteFlag = 0;
  tx_buff.ExternFlag = 0;
  tx_buff.SendType = 0;
  tx_buff.DataLen = 8;

  tx_buff.Data[0] = 0x40;
  tx_buff.Data[1] = enable;
  tx_buff.Data[2] = ch;
  tx_buff.Data[3] = 0x00;
  tx_buff.Data[4] = 0x00;
  tx_buff.Data[5] = 0x00;
  tx_buff.Data[6] = 0x00;
  tx_buff.Data[7] = 0x00;

  if (VCI_Transmit(VCI_USBCAN2, 0, 0, &tx_buff, 1) == 1)
  {
    // printf("TX data successful!\n");
  }
}

void cmd_velCallback(const geometry_msgs::Twist::ConstPtr &twist_aux)
{
  if ((twist_aux->linear.x == 0) &&
      (twist_aux->linear.y == 0) &&
      (twist_aux->angular.z != 0))
  {
    sendSpeedAkmMode(0, 0, twist_aux->angular.z);
    // printf("%f %f %f\n", twist_aux->linear.x, twist_aux->linear.y, twist_aux->angular.z);
  }
  else
  {
    sendSpeedFTFDMode(twist_aux->linear.x, twist_aux->linear.y, twist_aux->angular.z);
    // printf("%f %f %f\n", twist_aux->linear.x, twist_aux->linear.y, twist_aux->angular.z);
  }
}

void cmd_ChargeCallback(const std_msgs::UInt8 charge_type)
{
  sendChargeCtrl(charge_type.data);
}

int main(int argc, char **argv)
{
  int i = 0, re_size = 0;
  robiomni::ht_motion ht_motion_msg;
  robiomni::ht_drive_motor ht_drive_motor_msg;
  robiomni::ht_steering_motor ht_steering_motor_msg;
  robiomni::ht_system ht_system_msg;
  robiomni::ht_control ht_control_msg;

  robiomni::ht_rc_key ht_rc_key_msg;
  robiomni::ht_rc_rocker ht_rc_rocker_msg;
  robiomni::ht_charge ht_charge_msg;
  robiomni::ht_drive_motor_current ht_drive_motor_current_msg;
  robiomni::ht_drive_motor_error ht_drive_motor_error_msg;
  robiomni::ht_steering_motor_current ht_steering_motor_current_msg;
  robiomni::ht_steering_motor_error ht_steering_motor_error_msg;
  robiomni::ht_system_2 ht_system_2_msg;
  robiomni::ht_bms ht_bms_msg;
  sensor_msgs::BatteryState battery_state_msg;

  std_msgs::Bool std_stop_button;
  std_msgs::Bool std_software_stop;
  std_msgs::Bool std_front_collision;
  std_msgs::Bool std_rear_collision;

  printf(">>this is hello !\r\n"); // 指示程序已运行
  int num = VCI_OpenDevice(VCI_USBCAN2, 0, 0);
  if (num == 0 || num == 1) // 打开设备
  {
    printf(">>open deivce success!\n"); // 打开设备成功
  }
  else
  {
    printf(">>open deivce error %d!\n", num);
    exit(1);
  }
  if (VCI_ReadBoardInfo(VCI_USBCAN2, 0, &pInfo) == 1) // 读取设备序列号、版本等信息。
  {
    printf(">>Get VCI_ReadBoardInfo success!\n");
  }
  else
  {
    printf(">>Get VCI_ReadBoardInfo error!\n");
    exit(1);
  }

  // 初始化参数，严格参数二次开发函数库说明书。
  VCI_INIT_CONFIG config;
  config.AccCode = 0;
  config.AccMask = 0xFFFFFFFF; // FFFFFFFF全部接收
  config.Filter = 2;           // 接收所有帧  2-只接受标准帧  3-只接受扩展帧
  config.Timing0 = 0x00;       /*波特率500 Kbps  0x00  0x1C*/
  config.Timing1 = 0x1C;
  config.Mode = 0; // 正常模式

  if (VCI_InitCAN(VCI_USBCAN2, 0, 0, &config) != 1)
  {
    printf(">>Init CAN1 error\n");
    //VCI_CloseDevice(VCI_USBCAN2, 0);
  }

  if (VCI_StartCAN(VCI_USBCAN2, 0, 0) != 1)
  {
    printf(">>Start CAN1 error\n");
    //VCI_CloseDevice(VCI_USBCAN2, 0);
  }

  // 需要读取的帧，结构体设置
  VCI_CAN_OBJ rev[2500];
  rev[0].SendType = 0;
  rev[0].RemoteFlag = 0;
  rev[0].ExternFlag = 0;
  rev[0].DataLen = 8;

  ros::init(argc, argv, "robiomni_node");
  ros::NodeHandle n;

  ros::param::param<bool>("~robiomni_odom_enable", odom_enable, true);

  battery_state_msg.charge = NAN;
  battery_state_msg.capacity = NAN;
  battery_state_msg.design_capacity = NAN;
  battery_state_msg.power_supply_health = sensor_msgs::BatteryState::POWER_SUPPLY_HEALTH_UNKNOWN;
  battery_state_msg.power_supply_technology = sensor_msgs::BatteryState::POWER_SUPPLY_TECHNOLOGY_UNKNOWN;

  ros::Subscriber ht_control_sub = n.subscribe("/robiomni_Control", 100, cmd_velCallback);

  ros::Subscriber ht_charge_sub = n.subscribe("/robiomni_Charge_Ctrl", 100, cmd_ChargeCallback);

  ros::Subscriber ht_ftfd_sub = n.subscribe<geometry_msgs::Twist>("/robiomni_FTFD_Ctrl", 100,
  boost::function<void(const geometry_msgs::Twist::ConstPtr &)>(
  [&](const geometry_msgs::Twist::ConstPtr &twist)
  {
    sendSpeedFTFDMode(twist->linear.x, twist->linear.y, twist->angular.z);
  }));
  ros::Subscriber ht_ackermann_sub = n.subscribe<geometry_msgs::Twist>("/robiomni_Ackermann_Ctrl", 100,
  boost::function<void(const geometry_msgs::Twist::ConstPtr &)>(
  [&](const geometry_msgs::Twist::ConstPtr &twist)
  {
    sendSpeedAkmMode(twist->linear.x, twist->angular.z, 0);
  }));
  ros::Subscriber ht_double_ackermann_sub = n.subscribe<geometry_msgs::Twist>("/robiomni_Double_Ackermann_Ctrl", 100,
  boost::function<void(const geometry_msgs::Twist::ConstPtr &)>(
  [&](const geometry_msgs::Twist::ConstPtr &twist)
  {
    sendSpeedDoubleAkmMode(twist->linear.x, twist->angular.z, 0);
  }));
  ros::Subscriber ht_rotate_sub = n.subscribe<geometry_msgs::Twist>("/robiomni_Rotate_Ctrl", 100,
  boost::function<void(const geometry_msgs::Twist::ConstPtr &)>(
  [&](const geometry_msgs::Twist::ConstPtr &twist)
  {
    sendSpeedAkmMode(0, 0, twist->angular.z);
  }));
  ros::Subscriber ht_motion_sub = n.subscribe<robiomni::ht_motion>("/robiomni_Motion_Ctrl", 100,
  boost::function<void(const robiomni::ht_motion::ConstPtr &)>(
  [&](const robiomni::ht_motion::ConstPtr &motion)
  {
    if (motion->mode == 0x00)
    {
      sendSpeedAkmMode(motion->VX * 0.001f, angle_to_rad(motion->angle * 0.01f), motion->VZ * 0.001f);
    }

    if (motion->mode == 0x01)
    {
      sendSpeedFTFDMode(motion->vx * 0.001f, motion->vy * 0.001f, motion->vz * 0.001f);
    }
  }));
  ros::Subscriber ht_collision_sub = n.subscribe<std_msgs::Empty>("/robiomni_Collision_Clean", 100,
  boost::function<void(const std_msgs::Empty::ConstPtr &)>(
  [&](const std_msgs::Empty::ConstPtr)
  {
    sendCollisionClean();
  }));
  ros::Subscriber ht_lamp3_sub = n.subscribe<std_msgs::Bool>("/robiomni_Lamp_All_Ctrl", 100,
  boost::function<void(const std_msgs::Bool::ConstPtr &)>(
  [&](const std_msgs::Bool::ConstPtr &enable)
  {
    sendLampCtrl(0, enable->data);
  }));
  ros::Subscriber ht_lamp1_sub = n.subscribe<std_msgs::Bool>("/robiomni_Lamp1_Ctrl", 100,
  boost::function<void(const std_msgs::Bool::ConstPtr &)>(
  [&](const std_msgs::Bool::ConstPtr &enable)
  {
    sendLampCtrl(1, enable->data);
  }));
  ros::Subscriber ht_lamp2_sub = n.subscribe<std_msgs::Bool>("/robiomni_Lamp2_Ctrl", 100,
  boost::function<void(const std_msgs::Bool::ConstPtr &)>(
  [&](const std_msgs::Bool::ConstPtr &enable)
  {
    sendLampCtrl(2, enable->data);
  }));
  ros::Subscriber ht_odom_sub = n.subscribe<std_msgs::Empty>("/robiomni_Odom_Clean", 100,
  boost::function<void(const std_msgs::Empty::ConstPtr &)>(
  [&](const std_msgs::Empty::ConstPtr)
  {
    odom.clean();
  }));

  ros::Subscriber std_stop_ctrl_sub = n.subscribe<std_msgs::Bool>("/robiomni/std_stop_ctrl", 100,
  boost::function<void (const std_msgs::Bool::ConstPtr &)>(
  [&](const std_msgs::Bool::ConstPtr &msg)
  {
    /* do nothing */
  }));
  ros::Subscriber std_all_collision_clean_sub = n.subscribe<std_msgs::Empty>("/robiomni/std_all_collision_clean", 100,
  boost::function<void (const std_msgs::Empty::ConstPtr &)>(
  [&](const std_msgs::Empty::ConstPtr)
  {
    sendCollisionClean();
  }));
  ros::Subscriber std_front_collision_clean_sub = n.subscribe<std_msgs::Empty>("/robiomni/std_front_collision_clean", 100,
  boost::function<void (const std_msgs::Empty::ConstPtr &)>(
  [&](const std_msgs::Empty::ConstPtr)
  {
    sendCollisionClean();
  }));
  ros::Subscriber std_rear_collision_clean_sub = n.subscribe<std_msgs::Empty>("/robiomni/std_rear_collision_clean", 100,
  boost::function<void (const std_msgs::Empty::ConstPtr &)>(
  [&](const std_msgs::Empty::ConstPtr)
  {
    /* do nothing */
  }));
  ros::Subscriber std_all_lamp_ctrl_sub = n.subscribe<std_msgs::Bool>("/robiomni/std_all_lamp_ctrl", 100,
  boost::function<void (const std_msgs::Bool::ConstPtr &)>(
  [&](const std_msgs::Bool::ConstPtr &msg)
  {
    sendLampCtrl(0, msg->data);
  }));
  ros::Subscriber std_front_lamp_ctrl_sub = n.subscribe<std_msgs::Bool>("/robiomni/std_front_lamp_ctrl", 100,
  boost::function<void (const std_msgs::Bool::ConstPtr &)>(
  [&](const std_msgs::Bool::ConstPtr &msg)
  {
    sendLampCtrl(1, msg->data);
  }));
  ros::Subscriber std_rear_lamp_ctrl_sub = n.subscribe<std_msgs::Bool>("/robiomni/std_rear_lamp_ctrl", 100,
  boost::function<void (const std_msgs::Bool::ConstPtr &)>(
  [&](const std_msgs::Bool::ConstPtr &msg)
  {
    sendLampCtrl(2, msg->data);
  }));

  ros::Publisher ht_motion_pub = n.advertise<robiomni::ht_motion>("/robiomni_Motion", 100);                         // 运动状态消息发布
  ros::Publisher ht_system_pub = n.advertise<robiomni::ht_system>("/robiomni_System", 100);                         // 系统状态消息发布
  ros::Publisher ht_drive_motor_pub = n.advertise<robiomni::ht_drive_motor>("/robiomni_Drive_Motor", 100);          // 驱动电机状态消息发布
  ros::Publisher ht_steering_motor_pub = n.advertise<robiomni::ht_steering_motor>("/robiomni_Steering_Motor", 100); // 转向电机消息发布

  ros::Publisher ht_rc_rocker_pub = n.advertise<robiomni::ht_rc_rocker>("/robiomni_RemoteCtrl_Rocker", 100);
  ros::Publisher ht_rc_key_pub = n.advertise<robiomni::ht_rc_key>("/robiomni_RemoteCtrl_Key", 100);
  ros::Publisher ht_charge_pub = n.advertise<robiomni::ht_charge>("/robiomni_Charge_State", 100);

  ros::Publisher ht_drive_motor_current_pub = n.advertise<robiomni::ht_drive_motor_current>("/robiomni_Drive_Motor_Current", 100);
  ros::Publisher ht_drive_motor_error_pub = n.advertise<robiomni::ht_drive_motor_error>("/robiomni_Drive_Motor_Error", 100);
  ros::Publisher ht_steering_motor_current_pub = n.advertise<robiomni::ht_steering_motor_current>("/robiomni_Steering_Motor_Current", 100);
  ros::Publisher ht_steering_motor_error_pub = n.advertise<robiomni::ht_steering_motor_error>("/robiomni_Steering_Motor_Error", 100);
  ros::Publisher ht_system_2_pub = n.advertise<robiomni::ht_system_2>("/robiomni_System_2", 100);
  ros::Publisher ht_odom_pub = n.advertise<nav_msgs::Odometry>("/robiomni_Odom_Info", 100);
  ros::Publisher ht_battery_pub = n.advertise<sensor_msgs::BatteryState>("/robiomni_Battery_State", 100);
  ros::Publisher ht_bms_pub = n.advertise<robiomni::ht_bms>("/robiomni_BMS_Info", 100);

  ros::Publisher std_stop_button_pub     = n.advertise<std_msgs::Bool>("/robiomni/std_stop_button_info", 100);
  ros::Publisher std_software_stop_pub   = n.advertise<std_msgs::Bool>("/robiomni/std_software_stop_info", 100);
  ros::Publisher std_front_collision_pub = n.advertise<std_msgs::Bool>("/robiomni/std_front_collision_info", 100);
  ros::Publisher std_rear_collision_pub  = n.advertise<std_msgs::Bool>("/robiomni/std_rear_collision_info", 100);

  ros::Rate loop_rate(50);

  while (ros::ok())
  {
    // 读取数据
    re_size = (int)VCI_Receive(VCI_USBCAN2, 0, 0, rev, 2500, 0);
    if (re_size == -1)
    {
      std::cerr << "CAN Disconnected" << endl;
      ros::shutdown();
    }
    else if ((re_size > 0) && (re_size != -1))
    {
      if(re_size > 2500) {re_size = 2500;}
      for (int i = 0; i < re_size; i++)
      {
        // 运动状态反馈
        if ((rev[i].ID == 0x10) && (rev[i].Data[0] == 01) && (rev[i].Data[1] == 00)) // can发送00代表阿克曼模式
        {
          mode = 0;
          ht_motion_msg.mode = mode;
          ht_motion_msg.VX = (rev[i].Data[3] << 8) | rev[i].Data[2];
          int16_t angle = (rev[i].Data[5] << 8) | rev[i].Data[4];
          ht_motion_msg.angle = angle;
          ht_motion_msg.VZ = (rev[i].Data[7] << 8) | rev[i].Data[6];
          ht_motion_msg.vx = 0.0;
          ht_motion_msg.vy = 0.0;
          ht_motion_msg.vz = 0.0;
          ht_motion_pub.publish(ht_motion_msg);

          odomCalculation(odom, ht_odom_pub, 0, 0, ht_motion_msg.VZ * 0.001f);
        }
        else if ((rev[i].ID == 0x10) && (rev[i].Data[0] == 01) && (rev[i].Data[1] == 01)) // can发送01代表FTFD模式
        {
          mode = 1;
          ht_motion_msg.mode = 1;
          ht_motion_msg.VX = 0.0;
          ht_motion_msg.angle = 0.0;
          ht_motion_msg.VZ = 0.0;
          ht_motion_msg.vx = (rev[i].Data[3] << 8) | rev[i].Data[2];
          ht_motion_msg.vy = (rev[i].Data[5] << 8) | rev[i].Data[4];
          ht_motion_msg.vz = (rev[i].Data[7] << 8) | rev[i].Data[6];
          ht_motion_pub.publish(ht_motion_msg);

          odomCalculation(odom, ht_odom_pub, ht_motion_msg.vx * 0.001f, ht_motion_msg.vy * 0.001f, ht_motion_msg.vz * 0.001f);
        }
        if ((rev[i].ID == 0x10) && (rev[i].Data[0] == 01) && (rev[i].Data[1] == 02)) // can发送02代表双转阿克曼模式
        {
          mode = 2;
          ht_motion_msg.mode = 2;
          ht_motion_msg.VX = (rev[i].Data[3] << 8) | rev[i].Data[2];
          int16_t angle = (rev[i].Data[5] << 8) | rev[i].Data[4];
          ht_motion_msg.angle = angle;
          ht_motion_msg.VZ = (rev[i].Data[7] << 8) | rev[i].Data[6];
          ht_motion_msg.vx = 0.0;
          ht_motion_msg.vy = 0.0;
          ht_motion_msg.vz = 0.0;
          ht_motion_pub.publish(ht_motion_msg);

          odomCalculation(odom, ht_odom_pub, 0, 0, ht_motion_msg.VZ * 0.001f);
        }
        // 系统状态反馈
        else if (rev[i].ID == 0x11)
        {
          uint16_t voltage = (rev[i].Data[1] << 8) | rev[i].Data[0];
          uint8_t control_mode = rev[i].Data[2];
          uint8_t status = rev[i].Data[3];
          uint8_t drive_motor_error = rev[i].Data[4];
          uint8_t encode_error = rev[i].Data[5];
          ht_system_msg.voltage = voltage;
          ht_system_msg.control_mode = control_mode;
          ht_system_msg.status = status;
          ht_system_msg.drive_motor_error = drive_motor_error;
          ht_system_msg.encode_error = encode_error;

          ht_system_msg.front_left_abs_encode_error = (rev[i].Data[6] >> 0) & 0x01;
          ht_system_msg.front_right_abs_encode_error = (rev[i].Data[6] >> 1) & 0x01;
          ht_system_msg.rear_left_abs_encode_error = (rev[i].Data[6] >> 2) & 0x01;
          ht_system_msg.rear_right_abs_encode_error = (rev[i].Data[6] >> 3) & 0x01;
          ht_system_msg.battery_percent = rev[i].Data[7];

          std_stop_button.data     = (status >> 1) & 0x01;
          std_software_stop.data   = (status >> 3) & 0x01;

          ht_system_pub.publish(ht_system_msg);

          std_stop_button_pub.publish(std_stop_button);
          std_software_stop_pub.publish(std_software_stop);
        }
        // 驱动电机状态反馈
        else if ((rev[i].ID == 0x12) && (rev[i].Data[0] == 01))
        {
          uint8_t drive_motor_id = rev[i].Data[1];
          int16_t drive_motor_speed = (rev[i].Data[3] << 8) | rev[i].Data[2];
          uint32_t encoding_count = (rev[i].Data[7] << 24) | (rev[i].Data[6] << 16) | (rev[i].Data[5] << 8) | rev[i].Data[4];
          ht_drive_motor_msg.drive_motor_id = drive_motor_id;
          ht_drive_motor_msg.drive_motor_speed = drive_motor_speed;
          ht_drive_motor_msg.encoding_count = encoding_count;
          ht_drive_motor_pub.publish(ht_drive_motor_msg);
        }
        // 转向电机状态反馈
        else if ((rev[i].ID == 0x13) && (rev[i].Data[0] == 01))
        {
          uint8_t steering_motor_id = rev[i].Data[1];
          int16_t steering_motor_angle = (rev[i].Data[3] << 8) | rev[i].Data[2];
          ht_steering_motor_msg.steering_motor_id = steering_motor_id;
          ht_steering_motor_msg.steering_motor_angle = steering_motor_angle;
          ht_steering_motor_pub.publish(ht_steering_motor_msg);
        }
        else if (rev[i].ID == 0x14)
        {
          ht_charge_msg.is_offline = rev[i].Data[0];
          ht_charge_msg.state = rev[i].Data[1];
          ht_charge_msg.button = (rev[i].Data[2] >> 0) & 0x01;
          ht_charge_msg.relays = (rev[i].Data[2] >> 1) & 0x01;
          ht_charge_msg.voltage = (rev[i].Data[2] >> 2) & 0x01;
          ht_charge_msg.infrared = rev[i].Data[3];
          ht_charge_pub.publish(ht_charge_msg);
        }
        else if (rev[i].ID == 0x15)
        {
          ht_rc_rocker_msg.right_rocker_x = (int16_t)((rev[i].Data[1] << 8) | (rev[i].Data[0] << 0));
          ht_rc_rocker_msg.right_rocker_y = (int16_t)((rev[i].Data[3] << 8) | (rev[i].Data[2] << 0));
          ht_rc_rocker_msg.left_rocker_y = (int16_t)((rev[i].Data[5] << 8) | (rev[i].Data[4] << 0));
          ht_rc_rocker_msg.left_rocker_x = (int16_t)((rev[i].Data[7] << 8) | (rev[i].Data[6] << 0));

          ht_rc_rocker_pub.publish(ht_rc_rocker_msg);
        }
        else if (rev[i].ID == 0x16)
        {
          ht_rc_key_msg.left_round_vra = (int16_t)((rev[i].Data[1] << 8) | (rev[i].Data[0] << 0));
          ht_rc_key_msg.right_round_vrb = (int16_t)((rev[i].Data[3] << 8) | (rev[i].Data[2] << 0));

          ht_rc_key_msg.key_swa = (rev[i].Data[4] >> (0 * 2)) & 0x03;
          ht_rc_key_msg.key_swb = (rev[i].Data[4] >> (1 * 2)) & 0x03;
          ht_rc_key_msg.key_swc = (rev[i].Data[4] >> (2 * 2)) & 0x03;
          ht_rc_key_msg.key_swd = (rev[i].Data[4] >> (3 * 2)) & 0x03;

          ht_rc_key_msg.is_offline = (rev[i].Data[5] >> 0) & 0x01;

          ht_rc_key_pub.publish(ht_rc_key_msg);
        }
        else if (rev[i].ID == 0x30)
        {
          ht_system_2_msg.front_collision = (((uint16_t)((rev[i].Data[1] << 8) | (rev[i].Data[0] << 0))) >> 0) & 0x0001;
          ht_system_2_msg.back_collision = (((uint16_t)((rev[i].Data[1] << 8) | (rev[i].Data[0] << 0))) >> 1) & 0x0001;
          ht_system_2_msg.lamp_state = (((uint16_t)((rev[i].Data[1] << 8) | (rev[i].Data[0] << 0))) >> 2) & 0x0001;

          ht_system_2_msg.front_left_motor_offline = (rev[i].Data[2] >> 0) & 0x01;
          ht_system_2_msg.front_right_motor_offline = (rev[i].Data[2] >> 1) & 0x01;
          ht_system_2_msg.rear_left_motor_offline = (rev[i].Data[2] >> 2) & 0x01;
          ht_system_2_msg.rear_right_motor_offline = (rev[i].Data[2] >> 3) & 0x01;

          std_front_collision.data = ht_system_2_msg.front_collision;
          std_rear_collision.data  = ht_system_2_msg.back_collision;

          ht_system_2_pub.publish(ht_system_2_msg);

          std_front_collision_pub.publish(std_front_collision);
          std_rear_collision_pub.publish(std_rear_collision);
        }
        else if (rev[i].ID == 0x40)
        {
          ht_steering_motor_current_msg.front_left = ((int16_t)((rev[i].Data[1] << 8) | (rev[i].Data[0] << 0))) * 0.1f;
          ht_steering_motor_current_msg.front_right = ((int16_t)((rev[i].Data[3] << 8) | (rev[i].Data[2] << 0))) * 0.1f;
          ht_steering_motor_current_msg.rear_left = ((int16_t)((rev[i].Data[5] << 8) | (rev[i].Data[4] << 0))) * 0.1f;
          ht_steering_motor_current_msg.rear_right = ((int16_t)((rev[i].Data[7] << 8) | (rev[i].Data[6] << 0))) * 0.1f;

          ht_steering_motor_current_pub.publish(ht_steering_motor_current_msg);
        }
        else if (rev[i].ID == 0x41)
        {
          ht_drive_motor_current_msg.front_left = ((int16_t)((rev[i].Data[1] << 8) | (rev[i].Data[0] << 0))) * 0.1f;
          ht_drive_motor_current_msg.front_right = ((int16_t)((rev[i].Data[3] << 8) | (rev[i].Data[2] << 0))) * 0.1f;
          ht_drive_motor_current_msg.rear_left = ((int16_t)((rev[i].Data[5] << 8) | (rev[i].Data[4] << 0))) * 0.1f;
          ht_drive_motor_current_msg.rear_right = ((int16_t)((rev[i].Data[7] << 8) | (rev[i].Data[6] << 0))) * 0.1f;

          ht_drive_motor_current_pub.publish(ht_drive_motor_current_msg);
        }
        else if (rev[i].ID == 0x42)
        {
          ht_steering_motor_error_msg.front_left = (uint16_t)((rev[i].Data[1] << 8) | (rev[i].Data[0] << 0));
          ht_steering_motor_error_msg.front_right = (uint16_t)((rev[i].Data[3] << 8) | (rev[i].Data[2] << 0));
          ht_steering_motor_error_msg.rear_left = (uint16_t)((rev[i].Data[5] << 8) | (rev[i].Data[4] << 0));
          ht_steering_motor_error_msg.rear_right = (uint16_t)((rev[i].Data[7] << 8) | (rev[i].Data[6] << 0));

          ht_steering_motor_error_pub.publish(ht_steering_motor_error_msg);
        }
        else if (rev[i].ID == 0x43)
        {
          for (size_t loop = 0; loop < 4; loop++)
          {
            uint16_t drive_error = (uint16_t)((rev[i].Data[1 + (loop * 2)] << 8) | (rev[i].Data[0 + (loop * 2)] << 0));
            robiomni::ht_sdfz_error *sdfz_error = nullptr;

            if (loop == 0)
            {
              sdfz_error = &ht_drive_motor_error_msg.front_left;
            }
            if (loop == 1)
            {
              sdfz_error = &ht_drive_motor_error_msg.front_right;
            }
            if (loop == 2)
            {
              sdfz_error = &ht_drive_motor_error_msg.rear_left;
            }
            if (loop == 3)
            {
              sdfz_error = &ht_drive_motor_error_msg.rear_right;
            }

            *sdfz_error = robiomni::ht_sdfz_error();

            sdfz_error->internal = (drive_error >> 0) & 0x01;
            sdfz_error->encoder_abz = (drive_error >> 1) & 0x01;
            sdfz_error->encoder_uvw = (drive_error >> 2) & 0x01;
            sdfz_error->encoder_count = (drive_error >> 3) & 0x01;
            sdfz_error->drive_overtemp = (drive_error >> 4) & 0x01;
            sdfz_error->drive_bus_overvoltage = (drive_error >> 5) & 0x01;
            sdfz_error->drive_bus_undervoltage = (drive_error >> 6) & 0x01;
            sdfz_error->drive_short_circuit = (drive_error >> 7) & 0x01;
            sdfz_error->brake_overtemp = (drive_error >> 8) & 0x01;
            sdfz_error->actual_following = (drive_error >> 9) & 0x01;
            sdfz_error->reserved = (drive_error >> 10) & 0x01;
            sdfz_error->i2t = (drive_error >> 11) & 0x01;
            sdfz_error->speed_following = (drive_error >> 12) & 0x01;
            sdfz_error->motor_overtemp = (drive_error >> 13) & 0x01;
            sdfz_error->encoder_comm = (drive_error >> 14) & 0x01;
            sdfz_error->comm_loss = (drive_error >> 15) & 0x01;
          }

          ht_drive_motor_error_pub.publish(ht_drive_motor_error_msg);
        }
        else if (rev[i].ID == 0x50)
        {
          ht_bms_msg.is_offline            = (rev[i].Data[0] >> 0) & 0x01;
          ht_bms_msg.is_warning            = (rev[i].Data[0] >> 1) & 0x01;
          ht_bms_msg.charge_mos_is_open    = (rev[i].Data[0] >> 2) & 0x01;
          ht_bms_msg.discharge_mos_is_open = (rev[i].Data[0] >> 3) & 0x01;
          ht_bms_msg.state                 = rev[i].Data[1];
          ht_bms_msg.voltage               = ((uint16_t)((rev[i].Data[3] << 8) | (rev[i].Data[2] << 0))) * 0.1f;
          ht_bms_msg.current               = ((int16_t)((rev[i].Data[5] << 8) | (rev[i].Data[4] << 0))) * 0.1f;
          ht_bms_msg.soc                   = ((uint16_t)((rev[i].Data[7] << 8) | (rev[i].Data[6] << 0))) * 0.1f;

          battery_state_msg.header.stamp = ros::Time::now();
          battery_state_msg.voltage      = ht_bms_msg.voltage;
          battery_state_msg.current      = ht_bms_msg.current;
          battery_state_msg.percentage   = ht_bms_msg.soc * 0.01;
          battery_state_msg.present      = !ht_bms_msg.is_offline;

          if(ht_bms_msg.state == 0) {battery_state_msg.power_supply_status = sensor_msgs::BatteryState::POWER_SUPPLY_STATUS_NOT_CHARGING;}
          else if(ht_bms_msg.state == 1) {battery_state_msg.power_supply_status = sensor_msgs::BatteryState::POWER_SUPPLY_STATUS_CHARGING;}
          else if(ht_bms_msg.state == 2) {battery_state_msg.power_supply_status = sensor_msgs::BatteryState::POWER_SUPPLY_STATUS_DISCHARGING;}
          else {battery_state_msg.power_supply_status = sensor_msgs::BatteryState::POWER_SUPPLY_STATUS_UNKNOWN;}

          ht_bms_pub.publish(ht_bms_msg);
          ht_battery_pub.publish(battery_state_msg);
        }
        else if (rev[i].ID == 0x51)
        {
          ht_bms_msg.remain_capacity           = ((uint16_t)((rev[i].Data[1] << 8) | (rev[i].Data[0] << 0))) * 0.01f;
          ht_bms_msg.maximum_temperature_value = (int8_t)rev[i].Data[2];
          ht_bms_msg.minimum_temperature_value = (int8_t)rev[i].Data[3];

          battery_state_msg.header.stamp = ros::Time::now();
          battery_state_msg.temperature  = ht_bms_msg.maximum_temperature_value;

          ht_bms_pub.publish(ht_bms_msg);
          ht_battery_pub.publish(battery_state_msg);
        }
        else if (rev[i].ID == 0x52)
        {
          ht_bms_msg.warning.clear();

          for(int32_t warn_loop = 0; warn_loop < 8; warn_loop++)
          {
            ht_bms_msg.warning.push_back(rev[i].Data[warn_loop]);
          }

          ht_bms_pub.publish(ht_bms_msg);
        }
      }
    }
    ros::spinOnce();
    loop_rate.sleep();
  }
  VCI_CloseDevice(VCI_USBCAN2, 0); // 关闭设备。
  return 0;
}
